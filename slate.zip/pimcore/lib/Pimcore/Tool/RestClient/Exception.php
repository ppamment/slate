<?php
/**
 * Created by JetBrains PhpStorm.
 * User: jaichhorn
 * Date: 29.03.13
 * Time: 08:39
 * To change this template use File | Settings | File Templates.
 */

class Pimcore_Tool_RestClient_Exception extends Exception{


}