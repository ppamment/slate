<?php 

class Object_Artist extends Object_Concrete {

public $o_classId = 2;
public $o_className = "Artist";
public $name;
public $bio;


/**
* @param array $values
* @return Object_Artist
*/
public static function create($values = array()) {
	$object = new self();
	$object->setValues($values);
	return $object;
}

/**
* @return string
*/
public function getName () {
	$preValue = $this->preGetValue("name"); 
	if($preValue !== null && !Pimcore::inAdmin()) { return $preValue;}
	$data = $this->name;
	 return $data;
}

/**
* @param string $name
* @return void
*/
public function setName ($name) {
	$this->name = $name;
	return $this;
}

/**
* @return string
*/
public function getBio () {
	$preValue = $this->preGetValue("bio"); 
	if($preValue !== null && !Pimcore::inAdmin()) { return $preValue;}
	$data = $this->bio;
	 return $data;
}

/**
* @param string $bio
* @return void
*/
public function setBio ($bio) {
	$this->bio = $bio;
	return $this;
}

protected static $_relationFields = array (
);

public $lazyLoadedFields = NULL;

}

