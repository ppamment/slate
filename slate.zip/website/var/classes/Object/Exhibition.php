<?php 

class Object_Exhibition extends Object_Concrete {

public $o_classId = 3;
public $o_className = "Exhibition";


/**
* @param array $values
* @return Object_Exhibition
*/
public static function create($values = array()) {
	$object = new self();
	$object->setValues($values);
	return $object;
}

}

