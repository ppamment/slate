<?php 

class Object_Artwork_List extends Object_List_Concrete {

public $classId = 1;
public $className = "Artwork";


}
