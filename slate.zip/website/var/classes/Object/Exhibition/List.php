<?php 

class Object_Exhibition_List extends Object_List_Concrete {

public $classId = 3;
public $className = "Exhibition";


}
