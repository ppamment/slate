<?php 

class Object_Artist_List extends Object_List_Concrete {

public $classId = 2;
public $className = "Artist";


}
