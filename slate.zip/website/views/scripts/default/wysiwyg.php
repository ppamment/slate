<div class="row section_header">
    <div class="span4">
        <hr/>
    </div>
    <div class="span4">
        <h2><?php echo $this->input("title") ?></h2>
    </div>
    <div class="span4">
        <hr/>
    </div>
</div>

<?php echo $this->wysiwyg("content") ?>