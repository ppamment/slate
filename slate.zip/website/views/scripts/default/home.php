<div class="row section_header">
    <div class="span4">
        <hr/>
    </div>
    <div class="span4">
        <h2>Artwork Showcase</h2>
    </div>
    <div class="span4">
        <hr/>
    </div>
</div>
<ul class="thumbnails">
    <?php /** @var Object_Artwork $artwork */
    foreach($this->artworks as $artwork) : ?>
            <li class="span3">
                <a href="/artists/<?php echo $artwork->getParent()->getKey() ?>">
                    <div class="thumbnail">
                        <div class="thumb-image">
                            <img src="<?php echo $artwork->getImage()->getFullPath() ?>" />
                        </div>
                    </div>
                </a>
            </li>
    <?php endforeach; ?>
</ul>