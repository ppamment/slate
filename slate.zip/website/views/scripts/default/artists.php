<div class="row section_header">
    <div class="span4">
        <hr/>
    </div>
    <div class="span4">
        <h2>Artists</h2>
    </div>
    <div class="span4">
        <hr/>
    </div>
</div>

<div class="artists">
    <?php
    /** @var $artist Object_Artist */
    /** @var $artwork Object_Artwork */
    foreach($this->artists as $artist) : ?>
        <div class="row">
            <a href="/<?php echo $this->document->getKey() ?>/<?php echo $artist->getKey() ?>">
                <div class="well clearfix">
                    <div class="span3">
                        <h1><?php echo $artist->getName() ?></h1>
                        <p><?php echo $artist->getBio() ?></p>
                    </div>
                    <?php $artworks = array_slice($artist->getChilds(), 0, 3);
                    foreach($artworks as $artwork) : ?>
                        <div class="span3">
                            <div class="thumb-image-medium">
                                <img src="<?php echo $artwork->getImage()->getFullPath() ?>" />
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </a>
        </div>
    <?php endforeach ?>
</div>