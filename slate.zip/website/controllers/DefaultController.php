<?php

class DefaultController extends Website_Controller_Action
{

    public function preDispatch()
    {
        $this->enableLayout();
    }

    public function homeAction()
    {
        $list = new Object_Artwork_List();
        $list = iterator_to_array($list);
        array_rand($list);
        $list = array_slice($list, 0, 8);

        $this->view->artworks = $list;
    }

	public function wysiwygAction ()
    {

	}

    public function artistAction ()
    {
        $artistKey = $this->_getParam("artist");
        $artists = new Object_Artist_List();
        $artists->setCondition("o_key = '" . $artistKey . "'");

        $this->view->artist = current($artists->getObjects());
    }

    public function artistsAction()
    {
        $artists = new Object_Artist_List();
        $artists->setOrder("name");

        $this->view->artists = $artists;
    }
}
